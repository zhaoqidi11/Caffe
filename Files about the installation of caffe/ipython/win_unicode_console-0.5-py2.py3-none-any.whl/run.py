
def run():
	global run
	del run
	
	from win_unicode_console import runner
	
	runner.run_arguments()

if __name__ == "__main__":
	run()
