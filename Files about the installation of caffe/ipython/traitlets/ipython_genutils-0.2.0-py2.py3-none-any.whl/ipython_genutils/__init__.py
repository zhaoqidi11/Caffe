from ._version import __version__, version_info
