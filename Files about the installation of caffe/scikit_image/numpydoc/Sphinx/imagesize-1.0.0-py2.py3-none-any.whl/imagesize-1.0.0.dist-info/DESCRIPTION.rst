
It parses image files' header and return image size.

* PNG
* JPEG
* JPEG2000
* GIF

This is a pure Python library.


